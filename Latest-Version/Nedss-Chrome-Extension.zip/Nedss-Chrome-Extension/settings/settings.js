// تحميل الإعدادات
function loadSettings() {
    chrome.storage.local.get(
        "settings",
        (result) => {
            const settings = result.settings || {};

            document.getElementById("autoSearch").checked = settings.autoSearch || false;
            document.getElementById("showLinks").checked = settings.showLinks || false;
            document.getElementById("mergeTabs").checked = settings.mergeTabs || false;
            document.getElementById("highlightMissing").checked = settings.highlightMissing || false;
            document.getElementById("completionPercentage").checked = settings.completionPercentage || false;
            document.getElementById("menLab").checked = settings.menLab || false;
            
            document.getElementById("departmentSheet").value = settings.departmentSheet || "";
            document.getElementById("governorateSheet").value = settings.governorateSheet || "";
            document.getElementById("pdfFolder").value = settings.pdfFolder || "";
        }
    );
}

// 💡 دالة استخراج الـ ID الذكية من الروابط
function extractId(inputVal) {
    const value = inputVal.trim();
    if (!value) return "";

    // 1. فحص إذا كان الرابط هو رابط لملف Google Sheet
    // يبحث عن الجزء الواقع بين /d/ و /edit أو المائل التالي
    const sheetMatch = value.match(/\/d\/([a-zA-Z0-9-_]+)/);
    if (sheetMatch && sheetMatch[1]) {
        return sheetMatch[1];
    }

    // 2. فحص إذا كان الرابط هو رابط لمجلد Google Drive
    // يبحث عن الجزء الواقع بعد folders/ أو id=
    const folderMatch = value.match(/(?:folders\/|id=)([a-zA-Z0-9-_]+)/);
    if (folderMatch && folderMatch[1]) {
        return folderMatch[1];
    }

    // 3. إذا لم يكن رابطاً، يُفترض أنه ID جاهز فيتم إعادته كما هو
    return value;
}

// حفظ الإعدادات
function saveSettings() {
    // استخراج الـ IDs تلقائياً من الحقول قبل الحفظ
    const rawDept = document.getElementById("departmentSheet").value;
    const rawGov = document.getElementById("governorateSheet").value;
    const rawFolder = document.getElementById("pdfFolder").value;

    const settings = {
        autoSearch: document.getElementById("autoSearch").checked,
        mergeTabs: document.getElementById("mergeTabs").checked,
        highlightMissing: document.getElementById("highlightMissing").checked,
        completionPercentage: document.getElementById("completionPercentage").checked,
        menLab: document.getElementById("menLab").checked,
        showLinks: document.getElementById("showLinks").checked,

        // 💡 تطبيق الفلترة الذكية هنا وتحويل الروابط إلى IDs
        departmentSheet: extractId(rawDept),
        governorateSheet: extractId(rawGov),
        pdfFolder: extractId(rawFolder)
    };

    chrome.storage.local.set(
        { settings },
        () => {
            // تحديث الحقول على الشاشة فوراً بالـ IDs الجديدة المستخرجة ليرى المستخدم النتيجة
            document.getElementById("departmentSheet").value = settings.departmentSheet;
            document.getElementById("governorateSheet").value = settings.governorateSheet;
            document.getElementById("pdfFolder").value = settings.pdfFolder;

            alert("تم استخراج المعرفات وحفظ الإعدادات بنجاح! 🎉");
        }
    );
}

// تشغيل الصفحة
document.addEventListener(
    "DOMContentLoaded",
    () => {
        loadSettings();
        document
            .getElementById("saveButton")
            .addEventListener(
                "click",
                saveSettings
            );
    }
);
