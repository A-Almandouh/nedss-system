console.log("pathname =", location.pathname);

if (
    location.pathname.includes("Ext_") ||
    location.pathname.includes("AddNewRes.aspx")
) {
    console.log("CALLING RUN()");
    run();
}
else {
    console.log("PAGE NOT MATCHED");
}

async function getSettings() {
    const settings = JSON.parse(localStorage.getItem("settings")) || {};
    return settings;
}

chrome.runtime.onMessage.addListener((request) => {
    console.log("message received", request);
    if (request.action === "run") {
        run();
    }
});

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function run() {
    console.log("PAGE URL", location.href);

    // =====================================
    // EXTERNAL PAGE
    // =====================================
    if (
       location.pathname.includes("Ext_") ||
       location.pathname.includes("AddNewRes.aspx")
    ) {
        console.log("EXTERNAL PAGE DETECTED");
        try {
            const diseaseId = sessionStorage.getItem("DiseaseID");
            console.log("DiseaseID", diseaseId);

            const diseaseData = await extractDiseaseData(diseaseId);
            console.log("EXTERNAL DATA", diseaseData);

            const generalData = JSON.parse(sessionStorage.getItem("generalData") || "{}");
            console.log("GENERAL DATA", generalData);

            const merged = { ...generalData, ...diseaseData };
            console.log("MERGED DATA", merged);

            openTemplate(merged);
        } catch (err) {
            console.error("EXTERNAL ERROR", err);
        }
        return;
    }

    // =====================================
    // GENERAL PAGE
    // =====================================
    try {
        console.log("run started");
        const generalData = await extractData();
        console.log("GENERAL DATA", generalData);

        const diseaseId = generalData.DiseaseID;
        console.log("DiseaseID before routing =", generalData.DiseaseID);
        
        const route = await getDiseaseRoute(diseaseId, generalData.CaseID);
        console.log("ROUTE", route);

        // ============================
        // LINK MODE
        // ============================
        if (route.mode === "link") {
            console.log("LINK MODE");
            const link = document.querySelector("a.NavLink");
            if (!link) {
                throw new Error("NavLink not found");
            }
            link.click();
            await sleep(3000);

            const diseaseData = await extractDiseaseData(diseaseId);
            const merged = { ...generalData, ...diseaseData };
            openTemplate(merged);
            return;
        }

        // ============================
        // EXTERNAL MODE
        // ============================
        if (route.mode === "external") {
            console.log("EXTERNAL MODE");
            sessionStorage.setItem("generalData", JSON.stringify(generalData));
            sessionStorage.setItem("DiseaseID", diseaseId);
            console.log("GENERAL DATA SAVED");
            console.log("REDIRECT TO", route.finalUrl);
            location.href = route.finalUrl;
            return;
        }

        // ============================
        // GENERAL MODE
        // ============================
        if (route.mode === "general") {
            console.log("GENERAL MODE");
            openTemplate(generalData);
            return;
        }

        throw new Error("Unknown mode: " + route.mode);
    } catch (err) {
        console.error(err);
        alert(err.message);
    }
}

// =====================================
// AUTO RUN FOR ANY EXTERNAL PAGE
// =====================================
if (location.pathname.includes("Ext_")) {
    console.log("AUTO RUN EXTERNAL");
    run();
}

// =====================================
// OPEN TEMPLATE (💡 تم التعديل هنا لدمج الإعدادات بأمان)
// =====================================
function openTemplate(data) {
    const diseaseId = data.DiseaseID;
    console.log("DiseaseID in openTemplate =", diseaseId);
    const templateUrl = `https://a-almandouh.github.io/nedss-system/Templates/${diseaseId}.html`;

    console.log("OPEN TEMPLATE", templateUrl);
    const win = window.open(templateUrl, "_blank");

    if (!win) {
        alert("Popup blocked");
        return;
    }

    // جلب الإعدادات المحدثة من الإضافة لدمجها داخل البيانات المرسلة
    chrome.storage.local.get("settings", function(storageData) {
        const currentSettings = storageData.settings || {};
        
        // شحن كائن البيانات بالإعدادات تحت اسم appSettings
        const fullPayload = {
            ...data,
            appSettings: currentSettings
        };

        setTimeout(() => {
            console.log("📤 [content.js] تم تمرير البيانات مدمجة بالإعدادات بنجاح.");
            win.postMessage({
                type: "FILL_DATA",
                data: fullPayload
            }, "*");
        }, 2000);
    });
}

// تنفيذ الإعدادات البصرية فور التحميل
(async function () {
    const result = await chrome.storage.local.get("settings");
    const settings = result.settings || {};

    if (settings.autoSearch) autoSearch(); 
    if (settings.mergeTabs) mergeTabs();
    if (settings.highlightMissing) highlightMissing();
    if (settings.showLinks) showLinks();
    if (settings.menLab) menLab();
    if (settings.completionPercentage) completionPercentage();
})();

// فتح المحافظة فى ADI 
const GOVSELECT = document.getElementById("ContentPlaceHolder1_ddlGov");
if (GOVSELECT) { GOVSELECT.disabled = false; }

// فتح التقصى من صفحة استعراض الحالات
window.addEventListener("load", () => {
    const params = new URLSearchParams(location.search);
    if (params.get("autorun") === "1") {
        setTimeout(() => {
            run();
        }, 1500);
    }
});
// =====================================
// الغاء بعض الامراض من الاختيار
// =====================================
const currentUrlLower = window.location.href.toLowerCase();
const targetUrlLower = "https://nedss.mohp.gov.eg/nedss/webpages/generaldata/generalform.aspx?action=";

if (currentUrlLower.startsWith(targetUrlLower)) {
    const dropdownId = "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlDisease";
    const valuesToDisable = ["24", "25", "26", "59", "60", "63", "78","3", "4","6","8","12","75" ];

    // دالة أساسية لتعطيل العناصر وتغيير مظهرها
    function disableDropdownOptions() {
        const dropdown = document.getElementById(dropdownId);
        if (dropdown) {
            Array.from(dropdown.options).forEach(option => {
                if (valuesToDisable.includes(option.value)) {
                    option.disabled = true;
                    option.style.color = "#aaa"; 
                }
            });
        }
    }

    // التنفيذ الفوري الفعّال فور تحميل ملف الـ content script
    disableDropdownOptions();

    // تشغيل احتياطي عند اكتمال تحميل عناصر النافذة
    window.addEventListener("load", disableDropdownOptions);

    // مراقبة الصفحة لإعادة تطبيق التعطيل عند حدوث تحديثات جزئية (ASP.NET UpdatePanel)
    const observer = new MutationObserver(() => {
        disableDropdownOptions();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}
