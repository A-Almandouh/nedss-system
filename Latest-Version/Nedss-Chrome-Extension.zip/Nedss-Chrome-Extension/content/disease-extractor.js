console.log("disease-extractor loaded");

window.extractDiseaseData = extractDiseaseData;
const EXTRACTOR_BASE =
    "https://raw.githubusercontent.com/A-Almandouh/nedss-system/main/Extractors/";

async function loadDiseaseExtractor(diseaseId) {

    const url =
        EXTRACTOR_BASE + diseaseId + ".json";

    const response = await fetch(url);

    if (!response.ok) {
        return null;
    }

    return await response.json();
}

function getFieldValue(field) {
    switch (field.type) {
        case "select":
            const selectEl = document.getElementById(field.id);
            return selectEl ? (selectEl.options[selectEl.selectedIndex]?.text || "") : "";

        case "radio":
            const tableEl = document.getElementById(field.id);
            if (!tableEl) return "";

            const checkedRadio = tableEl.querySelector('input[type="radio"]:checked');
            if (!checkedRadio) return "";

            const label = document.querySelector(`label[for="${checkedRadio.id}"]`);
            return label ? label.innerText.trim() : "";

        // ==========================================
        // إضافة الحالة المخصصة لمربعات الاختيار (Checkbox)
        // ==========================================
        case "checkbox":
            const checkboxEl = document.getElementById(field.id);
            if (!checkboxEl) return "";
            // إذا كان المستخدم واضع علامة صح نرسل "on"، وإذا لم يضع نرسل نص فارغ
            return checkboxEl.checked ? "on" : "";

        case "value":
        case "text":
        default:
            const el = document.getElementById(field.id);
            return el ? el.value : "";
    }
}

async function extractDiseaseData(diseaseId) {

    const config =
        await loadDiseaseExtractor(diseaseId);

    if (!config) {
        return {};
    }

    const data = {};

    for (const key in config) {

        data[key] =
            getFieldValue(config[key]);
    }
    window.extractDiseaseData = extractDiseaseData;
    console.log("DISEASE DATA", data);
    
    return data;
}