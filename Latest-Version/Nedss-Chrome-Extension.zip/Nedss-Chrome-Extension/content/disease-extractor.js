console.log("disease-extractor loaded");

window.extractDiseaseData = extractDiseaseData;
const EXTRACTOR_BASE =
    "https://raw.githubusercontent.com/A-Almandouh/nedss-system/main/Extractors/";

async function loadDiseaseExtractor(diseaseId) {

    const url =
        EXTRACTOR_BASE + diseaseId + ".json";

    const response = await fetch(url);

    if (!response.ok) {
        return null;
    }

    return await response.json();
}

function getFieldValue(field) {
    switch (field.type) {
        case "select":
            const selectEl = document.getElementById(field.id);
            return selectEl ? (selectEl.options[selectEl.selectedIndex]?.text || "") : "";

        case "radio":
            // نقوم بجلب الجدول الحاوي للـ radio buttons باستخدام الـ id الموجود في الـ JSON
            const tableEl = document.getElementById(field.id);
            if (!tableEl) return "";

            // نبحث عن أي radio button داخل هذا الجدول يكون بحالة checked
            const checkedRadio = tableEl.querySelector('input[type="radio"]:checked');
            
            if (!checkedRadio) return "";

            // نجلب الـ label المرتبط بالـ id الخاص بالـ radio المختار
            // نستخدم القوسين [for="..."] للبحث عن الـ label الذي يشير لهذا الـ radio
            const label = document.querySelector(`label[for="${checkedRadio.id}"]`);
            return label ? label.innerText.trim() : "";

        case "value":
        case "text":
        default:
            const el = document.getElementById(field.id);
            return el ? el.value : "";
    }
}

async function extractDiseaseData(diseaseId) {

    const config =
        await loadDiseaseExtractor(diseaseId);

    if (!config) {
        return {};
    }

    const data = {};

    for (const key in config) {

        data[key] =
            getFieldValue(config[key]);
    }
    window.extractDiseaseData = extractDiseaseData;
    console.log("DISEASE DATA", data);
    
    return data;
}