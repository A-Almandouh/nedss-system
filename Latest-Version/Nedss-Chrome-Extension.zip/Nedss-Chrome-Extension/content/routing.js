console.log("routing loaded");

const ROUTING_URL =
    "https://raw.githubusercontent.com/A-Almandouh/nedss-system/main/Config/disease-routing.json";

async function loadRouting() {

    const res = await fetch(ROUTING_URL);

    if (!res.ok) {
        throw new Error("Routing load failed");
    }

    return await res.json();
}

async function getDiseaseRoute(diseaseId, caseId) {

    const routing = await loadRouting();

    const route = routing[diseaseId];

    if (!route) {
        return { mode: "general" };
    }

    let result = { ...route };

    if (
        result.mode === "external" &&
        result.appendCaseId &&
        caseId
    ) {

        const sep = result.url.includes("?") ? "&" : "?";

        result.finalUrl =
            result.url +
            sep +
            "caseid=" +
            encodeURIComponent(caseId);
    }

    return result;
}