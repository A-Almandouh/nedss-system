async function loadConfig() {

    const url =
        "https://raw.githubusercontent.com/A-Almandouh/nedss-system/main/Config/general-fields.json";

    const res = await fetch(url);

    if (!res.ok) {
        throw new Error(`Config Load Error: ${res.status}`);
    }

    return await res.json();
}

function getCaseIdFromUrl() {

  //  const params = new URLSearchParams(window.location.search);

  //  return params.get("caseid") || "";
  let caseId = new URLSearchParams(window.location.search).get("caseid");
    if (caseId) return caseId;

    const action = document.getElementById("aspnetForm")?.action;
    if (!action) return "";

    return new URL(action, window.location.origin)
        .searchParams
        .get("caseid") || "";
}


function getRadioValue(groupName) {

    const selected = document.querySelector(
        `input[name="${groupName}"]:checked`
    );

    if (!selected) return "";

    const label = document.querySelector(
        `label[for="${selected.id}"]`
    );

    return label ? label.innerText.trim() : selected.value;
}

function getValue(field) {

    switch (field.type) {

        case "url":

            if (field.source === "caseid") {
                return getCaseIdFromUrl();
            }

            return "";

        case "radio":

            return getRadioText(field.group);

        case "select": {

            const el = document.getElementById(field.id);

            if (!el)
                return "";

            return el.options[
                el.selectedIndex
            ]?.text || "";
        }

        case "value":
        case "text":
        default: {

            const el =
                document.getElementById(field.id);

            if (!el)
                return "";

            // INPUT
            if (
                el.tagName === "INPUT" ||
                el.tagName === "TEXTAREA"
            ) {

                return (
                    el.value || ""
                ).trim();
            }

            // SELECT
            if (
                el.tagName === "SELECT"
            ) {

                return el.options[
                    el.selectedIndex
                ]?.text || "";
            }

            // أى عنصر آخر
            return (
                el.innerText ||
                el.textContent ||
                ""
            ).trim();
        }
    }
}

async function extractData() {

    const config = await loadConfig();

    const data = {};

    for (const key in config) {

        data[key] = getValue(
            config[key]
        );
    }
        data.ReportingGov =
        data.ReportingGov ||
        getCellValueByLabel(
            "المحافظة"
        );

        data.ReportingDistrict =
        data.ReportingDistrict ||
        getCellValueByLabel(
            "الإدارة"
        );

    //------------------------------------
    // صفحة outCasess.aspx
    //------------------------------------
    if (
        location.href.includes(
            "outCasess.aspx"
        )
    ) {
        data.ReportingGov =
            getCellValueByLabel(
                "المحافظة"
            );

        data.ReportingDistrict =
            getCellValueByLabel(
                "الإدارة"
            );

        data.NotificationSource =
            getCellValueByLabel(
                "مصدر ابلاغ"
            );

        data.ReportDate =
            getCellValueByLabel(
                "تاريخ التقرير (ت اكتشاف الحالة)"
            );

        data.IsolationPlace =
            getCellValueByLabel(
                "القسم"
            );

        data.FirstName =
            getCellValueByLabel(
                "اسم الحالة"
            );

        data.FatherName =
            getCellValueByLabel(
                "اسم الاب"
            );

        data.GrandFatherName =
            getCellValueByLabel(
                "اسم الجد"
            );

        data.FamilyName =
            getCellValueByLabel(
                "اسم العائلة"
            );

        data.NationalID =
            getCellValueByLabel(
                "الرقم القومي"
            );

        data.Phone =
            getCellValueByLabel(
                "رقم التليفون"
            );
        
        data.DiseaseName =
            getCellValueByLabel(
                "المرض"
            );
        
        data.DiseaseName2 =
            getCellValueByLabel(
                "المرض"
            );

        if (!data.ResidenceGovernorate) {

        data.ResidenceGovernorate =
            getCellValueByLabel(
                "المحافظة",
                2
            );
                }

        if (!data.ResidenceDistrict) {

            data.ResidenceDistrict =
                getCellValueByLabel(
                    "الإدارة",
                    2
                );
        }
    }

    //------------------------------------
    data.PatientName = [

        data.FirstName,
        data.FatherName,
        data.GrandFatherName,
        data.FamilyName

    ]
        .filter(Boolean)
        .join(" ");

    console.log(
    "DiseaseID =",
    data.DiseaseID,
    data.DiseaseID
    );
    console.log(
        "Extracted Data:",
        data
    );

    return data;
}
//---------------------------------
function getSelectedText(selector) {

    const el = document.querySelector(selector);

    if (!el) return "";

    if (el.tagName === "SELECT") {

        const option =
            el.options[el.selectedIndex];

        return option
            ? option.text.trim()
            : "";
    }

    return "";
}

function getRadioText(groupName) {

    const checked =
        document.querySelector(
            `input[name="${groupName}"]:checked`
        );

    if (!checked)
        return "";

    const label =
        document.querySelector(
            `label[for="${checked.id}"]`
        );

    return label
        ? label.innerText.trim()
        : checked.value;
}

function getInputOrText(selector) {

    const el =
        document.querySelector(selector);

    if (!el)
        return "";

    // INPUT
    if (
        el.tagName === "INPUT" ||
        el.tagName === "TEXTAREA"
    ) {

        return (
            el.value || ""
        ).trim();
    }

    // SELECT
    if (
        el.tagName === "SELECT"
    ) {

        const option =
            el.options[
                el.selectedIndex
            ];

        return option
            ? option.text.trim()
            : "";
    }

    // SPAN
    return (
        el.innerText ||
        el.textContent ||
        ""
    ).trim();
}

function getCellValueByLabel(labelText, occurrence = 1) {

    const cells =
        document.querySelectorAll("td");

    let count = 0;

    for (const cell of cells) {

        const text =
            cell.innerText
                .replace(/\u00A0/g, "")
                .trim();

        if (text === labelText) {

            count++;

            if (count === occurrence) {

                const valueCell =
                    cell.nextElementSibling;

                if (!valueCell)
                    return "";

                return (
                    valueCell.innerText ||
                    valueCell.textContent ||
                    ""
                )
                    .replace(/\u00A0/g, "")
                    .trim();
            }
        }
    }

    return "";
}

