document
    .getElementById("run")
    .addEventListener(
        "click",
        async () => {

            try {

                const [tab] =
                    await chrome.tabs.query({

                        active: true,

                        currentWindow: true

                    });

                if (!tab) {

                    alert(
                        "لا توجد صفحة نشطة"
                    );

                    return;
                }

                await chrome.tabs.sendMessage(

                    tab.id,

                    {
                        action: "run"
                    }

                );

            }
            catch (err) {

                console.log(
                    err
                );

                alert(
                    "هذه الصفحة لا تدعم الإضافة أو لم يتم تحميل content.js بعد"
                );

            }

        }
    );

document
    .getElementById("settings")
    .addEventListener(
        "click",
        () => {

            window.open(

                "../settings/settings.html",

                "_blank"

            );

        }
    );

    document.getElementById("programsBtn").addEventListener("click", () => {
    const panel = document.getElementById("collapseExample");

    panel.style.display =
        panel.style.display === "none" ? "block" : "none";
});