const Cache = {

    async save(data){

        await chrome.storage.local.set({
            caseData:data
        });

    },

    async load(){

        const result =
        await chrome.storage.local.get("caseData");

        return result.caseData;

    }

};