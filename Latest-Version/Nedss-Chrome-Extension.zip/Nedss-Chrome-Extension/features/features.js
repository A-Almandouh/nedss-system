const result =
    await chrome.storage.local.get(
        "settings"
    );

const settings =
    result.settings || {};