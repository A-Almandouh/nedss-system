function mergeTabs() {

    const element =
        document.getElementById(
            "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2"
        );

    if (!element) return;

    element.style.display = "block";
    element.style.visibility = "visible";
}