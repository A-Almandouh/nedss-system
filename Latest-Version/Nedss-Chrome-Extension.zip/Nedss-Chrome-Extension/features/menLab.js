function menLab() {

    const ddl =
        document.getElementById(
            "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlDisease"
        );

    if (!ddl) return;

    const allowedValues =
        [35, 59, 60, 63, 70, 78];

    const selectedValue =
        parseInt(
            ddl.value,
            10
        );

    if (
        !allowedValues.includes(
            selectedValue
        )
    ) {
        return;
    }

    const formElement =
        document.getElementById(
            "aspnetForm"
        );

    if (!formElement) return;

    const caseidMatch =
        formElement.action.match(
            /caseid=([a-z0-9\-]+)/i
        );

    if (!caseidMatch) return;

    const caseid =
        caseidMatch[1];

    const url1 =
        `https://nedss.mohp.gov.eg/menLab/webpages/general/AddNewRes.aspx?action=edit&caseid=${caseid}`;

    const url2 =
        `https://nedss.mohp.gov.eg/menLab/webpages/general/AddNew.aspx?action=Add&caseid=${caseid}`;

    window.open(
        url1,
        "_blank"
    );

    window.open(
        url2,
        "_blank"
    );
}