function showLinks() {

    const table =
        document.querySelector(
            "#ctl00_ContentPlaceHolder1_cl1_gvCases"
        );

    if (!table) return;

    const headerRow =
        table.querySelector(
            "tr.headview"
        );

    const th =
        document.createElement("th");

    th.textContent = "";

    headerRow.appendChild(th);

    table
        .querySelectorAll(
            "tr.RowStyle, tr.AlternatingRowStyle"
        )
        .forEach(row => {

            const deleteLink =
                row.querySelector(
                    'a[href*="caseid="]'
                );

            if (!deleteLink) return;

            const match =
                deleteLink.href.match(
                    /caseid=([^&]+)/i
                );

            if (!match) return;

            const caseId = match[1];

            const td =
                document.createElement("td");

            const link =
                document.createElement("a");

            link.textContent =
                "فتح التقصي";

            link.target =
                "_blank";

            link.href =
                `https://nedss.mohp.gov.eg/nedss/WebPages/GeneralData/GeneralForm.aspx?action=edit&caseid=${caseId}&autorun=1`;

            td.appendChild(link);

            row.appendChild(td);
        });
}