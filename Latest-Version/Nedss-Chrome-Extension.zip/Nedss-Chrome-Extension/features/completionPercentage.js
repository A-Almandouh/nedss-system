function completionPercentage() {

    const calculateCompletionPercentage =
        () => {

            const fields =
                document.querySelectorAll(
                    "input, select, textarea"
                );

            let totalFields = 0;
            let completedFields = 0;

            fields.forEach(field => {

                if (
                    field.type === "hidden" ||
                    field.disabled ||
                    field.readOnly
                ) return;

                if (
                    field.type === "button" ||
                    field.type === "submit" ||
                    field.type === "reset"
                ) return;

                totalFields++;

                const value =
                    field.value
                        ? field.value.trim()
                        : "";

                if (
                    value !== "" &&
                    value !== "0"
                ) {

                    completedFields++;
                }
            });

            const percentage =
                totalFields === 0
                    ? 0
                    : Math.round(
                        ((completedFields) / totalFields) * 100
                    );

            const titleLabel =
                document.getElementById(
                    "ctl00_lblTitle"
                );

            if (titleLabel) {

                titleLabel.innerHTML =
                    `نسبة اكتمال البيانات ${percentage} %`;
            }
        };

    calculateCompletionPercentage();

    document.addEventListener(
        "input",
        calculateCompletionPercentage
    );

    document.addEventListener(
        "change",
        calculateCompletionPercentage
    );
}