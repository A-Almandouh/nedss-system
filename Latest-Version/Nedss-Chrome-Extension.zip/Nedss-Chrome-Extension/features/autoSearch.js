function autoSearch() {

    document.addEventListener('click', function (event) {

        if (
            event.target &&
            event.target.id === "ctl00_ContentPlaceHolder1_outcases1_btnSearch"
        ) {

            if (!sessionStorage.getItem('isSearchingNow')) {

                console.log("قام المستخدم بالبحث يدوياً. إيقاف السكريبت التلقائي مؤقتاً.");

                sessionStorage.setItem(
                    'userClickedSearch',
                    'true'
                );
            }
        }
    });

    if (sessionStorage.getItem('userClickedSearch')) {

        console.log(
            "تم تخطي السكريبت التلقائي للحفاظ على معايير بحث المستخدم."
        );

        sessionStorage.removeItem(
            'userClickedSearch'
        );

        return;
    }

    if (!sessionStorage.getItem('isSearchingNow')) {

        const searchButton =
            document.getElementById(
                "ctl00_ContentPlaceHolder1_outcases1_btnSearch"
            );

        if (searchButton) {

            console.log(
                "بدء عملية الفلترة والبحث التلقائي..."
            );

            sessionStorage.setItem(
                'isSearchingNow',
                'true'
            );

            const diseaseDropdown =
                document.getElementById(
                    "ctl00_ContentPlaceHolder1_outcases1_ddlDisease"
                );

            const statusDropdown =
                document.getElementById(
                    "ctl00_ContentPlaceHolder1_outcases1_ddlStatus"
                );

            if (diseaseDropdown) diseaseDropdown.value = "";
            if (statusDropdown) statusDropdown.value = "";

            if (diseaseDropdown) {
                diseaseDropdown.dispatchEvent(
                    new Event('change', { bubbles: true })
                );
            }

            if (statusDropdown) {
                statusDropdown.dispatchEvent(
                    new Event('change', { bubbles: true })
                );
            }

            const targetRadioButton =
                document.getElementById(
                    "ctl00_ContentPlaceHolder1_outcases1_rdoSource_2"
                );

            if (targetRadioButton) {

                targetRadioButton.checked = true;

                targetRadioButton.dispatchEvent(
                    new Event('change', { bubbles: true })
                );

                targetRadioButton.dispatchEvent(
                    new Event('click', { bubbles: true })
                );

                console.log(
                    "تم اختيار عنصر المصدر (Value = 3) بنجاح."
                );
            }

            setTimeout(() => {

                console.log(
                    "الضغط التلقائي على زر البحث..."
                );

                searchButton.click();

            }, 300);
        }
    }
    else {

        console.log(
            "اكتمل البحث التلقائي بنجاح."
        );

        setTimeout(() => {

            sessionStorage.removeItem(
                'isSearchingNow'
            );

        }, 1000);
    }
}