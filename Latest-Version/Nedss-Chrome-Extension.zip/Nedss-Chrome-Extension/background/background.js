console.log("background loaded");

chrome.runtime.onInstalled.addListener(() => {
    console.log("NEDSS Engine Ready");
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    if (msg.action === "OPEN_EXTERNAL") {

        chrome.tabs.create({
            url: msg.url
        });
    }
});