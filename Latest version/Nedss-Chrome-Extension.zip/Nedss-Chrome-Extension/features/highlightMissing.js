function highlightMissing() {

    const REQUIRED_FIELDS = [
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel1_txtNationalID",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel1_txtPhoneNo",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel1_ResAreaSelector1_txtStreet",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel1_ResAreaSelector1_ddlUnits",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel1_ResAreaSelector1_ddlRegions",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel1_txtName5",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlOccupation",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlMarStatus",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_cln_BirthDate_TxtDate",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_cln_OnsetDate_TxtDate",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_cln_AdmDate_TxtDate",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlOutCome",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_cln_NotDate_TxtDate",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_txtHosID",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_txtPhysName",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_clnDisDate_TxtDate",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_txtFinalDiagnosis",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlInitDiagnosis",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlSpec1",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlLabTest1",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlResult1",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlSpec2",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlLabTest2",
        "ctl00_ContentPlaceHolder1_generalform1_TabContainer1_TabPanel2_ddlResult2"
    ];

    REQUIRED_FIELDS.forEach(id => {

        const field =
            document.getElementById(id);

        if (!field) return;

        if (
            field.value === "" ||
            field.value === "0"
        ) {

            field.style.background =
                "#ffcccc";
        }
        else {

            field.style.background =
                "";
        }

        if (!field.dataset.hasListener) {

            field.addEventListener(
                'input',
                () => {

                    if (
                        field.value !== "" &&
                        field.value !== "0"
                    ) {

                        field.style.background =
                            "";
                    }
                }
            );

            field.dataset.hasListener =
                "true";
        }
    });

    console.log(
        "تم تنفيذ تمييز الحقول الفارغة بنجاح."
    );
}