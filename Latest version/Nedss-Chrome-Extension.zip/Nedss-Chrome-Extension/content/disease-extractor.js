console.log("disease-extractor loaded");

window.extractDiseaseData = extractDiseaseData;
const EXTRACTOR_BASE =
    "https://raw.githubusercontent.com/A-Almandouh/nedss-system/main/Extractors/";

async function loadDiseaseExtractor(diseaseId) {

    const url =
        EXTRACTOR_BASE + diseaseId + ".json";

    const response = await fetch(url);

    if (!response.ok) {
        return null;
    }

    return await response.json();
}

function getFieldValue(field) {

    const el = document.getElementById(field.id);

    if (!el) return "";

    switch (field.type) {

        case "select":
            return el.options[el.selectedIndex]?.text || "";

        case "value":
            return el.value || "";

        case "text":
            return el.value || "";

        default:
            return el.value || "";
    }
}

async function extractDiseaseData(diseaseId) {

    const config =
        await loadDiseaseExtractor(diseaseId);

    if (!config) {
        return {};
    }

    const data = {};

    for (const key in config) {

        data[key] =
            getFieldValue(config[key]);
    }
    window.extractDiseaseData = extractDiseaseData;
    console.log("DISEASE DATA", data);
    
    return data;
}