// تحميل الإعدادات
function loadSettings() {

    chrome.storage.local.get(
        "settings",
        (result) => {

            const settings =
                result.settings || {};

            document.getElementById("autoSearch").checked =
                settings.autoSearch || false;

            document.getElementById("showLinks").checked =
                settings.showLinks || false;

            
            document.getElementById("mergeTabs").checked =
                settings.mergeTabs || false;

            document.getElementById("highlightMissing").checked =
                settings.highlightMissing || false;

            document.getElementById("completionPercentage").checked =
                settings.completionPercentage || false;

            document.getElementById("menLab").checked =
                settings.menLab || false;

            
            document.getElementById("departmentSheet").value =
                settings.departmentSheet || "";

            document.getElementById("governorateSheet").value =
                settings.governorateSheet || "";

            document.getElementById("pdfFolder").value =
                settings.pdfFolder || "";

            
        }
    );
}


// حفظ الإعدادات
function saveSettings() {

    const settings = {

        autoSearch:
            document.getElementById("autoSearch").checked,

        mergeTabs:
            document.getElementById("mergeTabs").checked,

        highlightMissing:
            document.getElementById("highlightMissing").checked,

        completionPercentage:
            document.getElementById("completionPercentage").checked,

        menLab:
            document.getElementById("menLab").checked,

               
        
        showLinks:
            document.getElementById("showLinks").checked,

        
        

        departmentSheet:
            document.getElementById("departmentSheet").value.trim(),

        governorateSheet:
            document.getElementById("governorateSheet").value.trim(),

        pdfFolder:
            document.getElementById("pdfFolder").value.trim(),

        

        

    };

    chrome.storage.local.set(
        { settings },
        () => {

            alert(
                "تم حفظ الإعدادات بنجاح"
            );

        }
    );

}


// تشغيل الصفحة
document.addEventListener(
    "DOMContentLoaded",
    () => {

        loadSettings();

        document
            .getElementById("saveButton")
            .addEventListener(
                "click",
                saveSettings
            );

    }
);